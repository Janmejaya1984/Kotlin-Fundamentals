fun main(args: Array<String>) {
    val number = 24
    val isEven = if(number % 2 == 0) "Number is even" else "Number is odd"

    println(isEven)
}