fun main(args: Array<String>) {
    var puzzlePieces = 20
    var piecesPlaced = 0
    while(piecesPlaced < puzzlePieces) {
        piecesPlaced++
        println("Placed piece #$piecesPlaced")
    }
}