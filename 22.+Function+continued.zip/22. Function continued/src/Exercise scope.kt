fun main(args: Array<String>) {
    val parakeets = 5
    buyMoreParakeets(parakeets)
    println("You now have $parakeets parakeets")
}

fun buyMoreParakeets(parakeets: Int) {
    val parakeets = 3
}