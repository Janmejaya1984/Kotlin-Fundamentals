fun main(args: Array<String>) {
    example()
//    println("He has $flowers flowers")
}

fun example() {
    val flowers = 5
    println("I have $flowers flowers")
}