fun main(args: Array<String>) {
    val myLambda = {name: String -> println("Hello $name")}
}
