package com.catalin.printhello

fun hi() {
    println("Hello how are you?")
}