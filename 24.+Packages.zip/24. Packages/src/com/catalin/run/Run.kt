package com.catalin.run

import com.catalin.printhello.*

fun main(args: Array<String>) {
    hi()
}