package com.exercise.hello

fun sayHi(clientName: String) {
    println("Hello $clientName")
}