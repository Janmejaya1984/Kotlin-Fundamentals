package com.exercise.run

import com.exercise.client.getName

fun main(args: Array<String>) {
    getName()
}