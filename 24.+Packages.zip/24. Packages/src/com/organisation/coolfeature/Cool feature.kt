package com.organisation.coolfeature

fun buildCoolFeature() {
    println("Building a cool feature for our project")
}

fun testCoolFeature() {
    println("Testing a cool feature")
}

fun launchCoolFeature() {
    println("Launching cool feature")
}