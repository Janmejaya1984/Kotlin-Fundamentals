package com.organisation.main

import com.organisation.coolfeature.*

fun main(args: Array<String>) {
    buildCoolFeature()
    testCoolFeature()
    launchCoolFeature()
}