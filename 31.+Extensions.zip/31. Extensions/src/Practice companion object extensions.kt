fun main(args: Array<String>) {
    String.getClassType()
}

fun String.Companion.getClassType() {
    println("This is a String class")
}