fun main(args: Array<String>) {
    var line1 = "(\\(\\"
    var line2 = "(-.-)"
    var line3 = "o_(\")(\")"

    println(line1)
    println(line2)
    println(line3)
}