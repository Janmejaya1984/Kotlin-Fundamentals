const val URL_LINK = "google.com"

fun main(args: Array<String>) {
    println("Accessing URL $URL_LINK")
}