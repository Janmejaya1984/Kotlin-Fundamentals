fun main(args: Array<String>) {
    val client = "Mary"
    val products = 3
    val price = 30

    println("Hello $client your total amount is ${products * price}")
}