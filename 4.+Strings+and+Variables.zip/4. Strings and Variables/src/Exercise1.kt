fun main(args: Array<String>) {
    val catName = "My cat's name is \"Fluffy\""
    println(catName)

    var slashes = "Two types of slashes: \\ and /"
    println(slashes)

    var url = "http://www.google.com"
    println(url)
}