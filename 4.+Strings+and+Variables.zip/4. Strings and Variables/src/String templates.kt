fun main(args: Array<String>) {
    val dogName = "Teddy"
    println("My dog's name is $dogName")

    println("I have ${10/2} cats")
}