fun main(args: Array<String>) {
    println("The answer is \"yes\" so you can proceed")
    println("I like to put a \\ in my code")
}