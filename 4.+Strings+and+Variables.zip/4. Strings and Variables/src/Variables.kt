fun main(args: Array<String>) {
    var tvShows = "many"
    println(tvShows)
    tvShows = "too many"
    println(tvShows)

//    var age = 25
//    age = "many"

    val color = "blue"
//    color = "red"
}