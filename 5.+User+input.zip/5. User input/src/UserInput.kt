fun main(args: Array<String>) {
    println("Input something")
    val userInput = readLine()
    println("You wrote: $userInput")
}