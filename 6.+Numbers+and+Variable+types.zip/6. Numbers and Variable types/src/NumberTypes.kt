fun main(args: Array<String>){
    var items = 5
    println(items::class.java)

    var nbOfPeople = 7500000000
    println(nbOfPeople::class.java)

    var price = 29.99
    println(price::class.java)

    var pi = 3.14159834763945
    println(pi::class.java)
}