fun main(args: Array<String>){
    var price = 34
    var items = 3
    var totalPrice = price * items
    println("Total price is $totalPrice")
}