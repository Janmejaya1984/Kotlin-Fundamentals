fun main(args: Array<String>){
    val var1 = 45
    println(var1)
    println(var1::class.java)

    val var2 = 3894762384576
    println(var2)
    println(var2::class.java)

    val var3 = 234.67
    println(var3)
    println(var3::class.java)
}