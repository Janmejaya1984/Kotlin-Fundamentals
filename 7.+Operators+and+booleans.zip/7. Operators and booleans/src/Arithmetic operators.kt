fun main(args: Array<String>) {
    println(5+2)
    println("Hi" + " John")

    println(5-2)

    println(5*2)

    println(5/2)
    println(5f/2f)

    println(10%5)

    var cats = 5
    cats++
    println("I now have $cats cats")

    cats--
    println("A cat passed away. I now have $cats cats")

    var dogs = 2
    println("I have ${++dogs} dogs")
}