fun main(args: Array<String>) {
    val dozen = 12
    val months = dozen
    println(months)

    val userName = "Lucy"
    val greeting = "Hello, $userName"
    println(greeting)

    val products = 3
    val price = 9.99
    println("Your total is ${products * price}")
}