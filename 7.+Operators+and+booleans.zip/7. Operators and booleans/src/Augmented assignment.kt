fun main(args: Array<String>) {
    var bikes = 5
    bikes + 1
    println(bikes)
    bikes += 3
    println(bikes)

    bikes -= 4
    println(bikes)

    bikes *= 2
    println(bikes)

    bikes /= 2
    println(bikes)

    bikes = 5
    bikes %= 2
    println(bikes)
}