fun main(args: Array<String>) {
    var catName: String? = null
    println(catName!!.length)
}