fun main(args: Array<String>) {
    val herName: String = "Lilly"
    val hisName: String? = null
    println(herName)
    println(hisName)

    var catName: String? = "Chonkers"
    catName = null

    var dogName: String = "Fluffy"
//    dogName = null
}