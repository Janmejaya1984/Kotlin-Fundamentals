fun main(args: Array<String>) {
    var test = readLine()
    println(test?.toInt())
}